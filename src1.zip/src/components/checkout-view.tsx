'use client';

import { useStore } from '@/lib/store';
import { useCurrency } from '@/lib/currency';
import { useTranslation } from '@/hooks/useTranslation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  ArrowLeft,
  Loader2,
  Lock,
  Truck,
  Gift,
  Tag,
  ChevronDown,
  ChevronUp,
  CheckCircle,
  XCircle,
  ShoppingBag,
  ShieldCheck,
  Check,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useState } from 'react';

interface CouponResult {
  valid: boolean;
  discount?: number;
  error?: string;
  offer?: {
    id: string;
    title: string;
    code: string;
    type: string;
    value: number;
  };
}

export function CheckoutView() {
  const { cartItems, setView, clearCart } = useStore();
  const { format } = useCurrency();
  const { t } = useTranslation();

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const [deliveryType, setDeliveryType] = useState('standard');
  const [giftWrapping, setGiftWrapping] = useState(false);
  const [giftWrapStyle, setGiftWrapStyle] = useState('classic');
  const [greetingMessage, setGreetingMessage] = useState('');
  const [hidePrice, setHidePrice] = useState(false);
  const [giftOptionsOpen, setGiftOptionsOpen] = useState(false);
  const [couponCode, setCouponCode] = useState('');
  const [discount, setDiscount] = useState(0);
  const [couponResult, setCouponResult] = useState<CouponResult | null>(null);
  const [couponLoading, setCouponLoading] = useState(false);
  const [checkoutLoading, setCheckoutLoading] = useState(false);
  const [checkoutError, setCheckoutError] = useState<string | null>(null);
  const [orderSuccess, setOrderSuccess] = useState(false);
  const [orderNumber, setOrderNumber] = useState('');

  const DELIVERY_OPTIONS = [
    {
      id: 'standard',
      label: t('checkout.standardDelivery'),
      description: t('checkout.freeOverAmount', { amount: format(500) }),
      price: 0,
      estimatedDays: t('checkout.businessDays', { days: '5-7' }),
    },
    {
      id: 'express',
      label: t('checkout.expressDelivery'),
      description: format(150),
      price: 150,
      estimatedDays: t('checkout.businessDays', { days: '2-3' }),
    },
    {
      id: 'same-day',
      label: t('checkout.sameDayDelivery'),
      description: format(250),
      price: 250,
      estimatedDays: t('checkout.businessDays', { days: '1' }),
    },
  ];

  const GIFT_WRAP_STYLES = [
    { value: 'classic', label: t('checkout.classic'), description: t('checkout.classicDesc') },
    { value: 'premium', label: t('checkout.premium'), description: t('checkout.premiumDesc') },
    { value: 'luxury', label: t('checkout.luxury'), description: t('checkout.luxuryDesc') },
  ];

  const selectedDelivery = DELIVERY_OPTIONS.find((d) => d.id === deliveryType) || DELIVERY_OPTIONS[0];
  const deliveryCost = selectedDelivery.price;

  const shipping = deliveryType === 'standard'
    ? (subtotal > 500 ? 0 : 50)
    : deliveryType === 'express' ? 150 : deliveryType === 'same-day' ? 250 : deliveryCost;
  const tax = subtotal * 0.08;
  const total = subtotal + shipping + tax - discount;

  const [form, setForm] = useState({
    email: '',
    firstName: '',
    lastName: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    country: 'IN',
    phone: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!form.email) newErrors.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(form.email)) newErrors.email = 'Invalid email';
    if (!form.firstName) newErrors.firstName = 'First name is required';
    if (!form.lastName) newErrors.lastName = 'Last name is required';
    if (!form.address) newErrors.address = 'Address is required';
    if (!form.city) newErrors.city = 'City is required';
    if (!form.state) newErrors.state = 'State is required';
    if (!form.zipCode) newErrors.zipCode = 'ZIP code is required';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleApplyCoupon = async () => {
    if (!couponCode.trim()) return;
    setCouponLoading(true);
    setCouponResult(null);
    try {
      const res = await fetch('/api/offers/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: couponCode.trim(), subtotal }),
      });
      const data: CouponResult = await res.json();
      setCouponResult(data);
      if (data.valid && data.discount) {
        setDiscount(data.discount);
      } else {
        setDiscount(0);
      }
    } catch {
      setCouponResult({ valid: false, error: 'Failed to validate coupon' });
      setDiscount(0);
    } finally {
      setCouponLoading(false);
    }
  };

  const handleRemoveCoupon = () => {
    setCouponCode('');
    setCouponResult(null);
    setDiscount(0);
  };

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    setCheckoutError(null);

    if (!validate()) return;

    if (cartItems.length === 0) {
      setCheckoutError('Your cart is empty. Please add products before checkout.');
      return;
    }

    setCheckoutLoading(true);
    try {
      const checkoutItems = cartItems.map((item) => ({
        productId: item.productId,
        variantId: item.variantId || undefined,
        quantity: item.quantity,
        giftWrapping: giftWrapping,
        greetingMessage: greetingMessage || null,
        hidePrice: hidePrice,
      }));

      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: form.email,
          firstName: form.firstName,
          lastName: form.lastName,
          address: form.address,
          city: form.city,
          state: form.state,
          zipCode: form.zipCode,
          country: form.country,
          phone: form.phone,
          items: checkoutItems,
          deliveryType,
          occasion: undefined,
          giftWrapping,
          giftWrapStyle: giftWrapping ? giftWrapStyle : undefined,
          greetingMessage: greetingMessage || undefined,
          hidePrice,
          couponCode: couponCode || undefined,
          paymentMethod: 'card',
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Failed to place order');
      }

      // Order placed successfully
      setOrderNumber(data.orderNumber);
      setOrderSuccess(true);
      clearCart();

    } catch (error: any) {
      console.error('Checkout error:', error);
      setCheckoutError(error.message || 'Failed to place order. Please try again.');
    } finally {
      setCheckoutLoading(false);
    }
  };

  const updateField = (field: string, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[field];
        return next;
      });
    }
  };

  // Order Success View
  if (orderSuccess) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="flex flex-col items-center justify-center py-16 text-center"
      >
        <div className="mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-emerald-900/30 border border-emerald-500/30">
          <Check className="h-10 w-10 text-emerald-400" />
        </div>
        <h2 className="text-2xl font-bold text-amber-100">Order Placed Successfully!</h2>
        <p className="mt-2 text-amber-200/60">Thank you for your purchase</p>
        <div className="mt-4 rounded-lg border border-amber-900/20 bg-stone-900/60 px-6 py-4">
          <p className="text-sm text-amber-200/50">Order Number</p>
          <p className="text-lg font-bold text-amber-400">{orderNumber}</p>
        </div>
        <p className="mt-4 max-w-md text-sm text-amber-200/40">
          A confirmation email has been sent to {form.email}. You can track your order status from your account.
        </p>
        <Button
          onClick={() => setView('home')}
          className="mt-6 bg-amber-600 text-stone-950 hover:bg-amber-500"
        >
          Continue Shopping
        </Button>
      </motion.div>
    );
  }

  if (cartItems.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16">
        <p className="text-amber-200/60">{t('cart.empty')}</p>
        <Button
          onClick={() => setView('home')}
          className="mt-4 bg-amber-600 text-stone-950 hover:bg-amber-500"
        >
          {t('cart.shopNow')}
        </Button>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="py-8"
    >
      <Button
        variant="ghost"
        onClick={() => setView('cart')}
        className="mb-6 text-amber-200/60 hover:bg-amber-900/20 hover:text-amber-400"
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        {t('checkout.backToCart')}
      </Button>

      <h2 className="text-2xl font-bold text-amber-100">{t('checkout.title')}</h2>

      {/* Secure Checkout Badge */}
      <div className="mt-3 flex items-center gap-2 rounded-lg border border-amber-600/30 bg-amber-900/10 px-4 py-2.5">
        <ShieldCheck className="h-5 w-5 text-amber-500" />
        <div>
          <p className="text-sm font-semibold text-amber-200">Secure Checkout</p>
          <p className="text-xs text-amber-200/40">Your payment information is processed securely</p>
        </div>
        <Lock className="ml-auto h-4 w-4 text-amber-500/60" />
      </div>

      <form onSubmit={handleCheckout}>
        <div className="mt-6 grid gap-8 lg:grid-cols-3">
          {/* Form Fields */}
          <div className="lg:col-span-2 space-y-8">
            {/* Contact */}
            <div className="rounded-lg border border-amber-900/20 bg-stone-900/60 p-6">
              <h3 className="text-lg font-semibold text-amber-100">{t('checkout.contactInfo')}</h3>
              <div className="mt-4">
                <Label htmlFor="email" className="text-amber-200/60">{t('checkout.email')}</Label>
                <Input
                  id="email"
                  type="email"
                  value={form.email}
                  onChange={(e) => updateField('email', e.target.value)}
                  placeholder="your@email.com"
                  className="mt-1 border-amber-900/40 bg-stone-800/50 text-amber-50 placeholder:text-amber-200/20"
                />
                {errors.email && <p className="mt-1 text-xs text-red-400">{errors.email}</p>}
              </div>
            </div>

            {/* Shipping */}
            <div className="rounded-lg border border-amber-900/20 bg-stone-900/60 p-6">
              <h3 className="text-lg font-semibold text-amber-100">{t('checkout.shippingAddress')}</h3>
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                <div>
                  <Label htmlFor="firstName" className="text-amber-200/60">{t('checkout.firstName')}</Label>
                  <Input
                    id="firstName"
                    value={form.firstName}
                    onChange={(e) => updateField('firstName', e.target.value)}
                    className="mt-1 border-amber-900/40 bg-stone-800/50 text-amber-50"
                  />
                  {errors.firstName && <p className="mt-1 text-xs text-red-400">{errors.firstName}</p>}
                </div>
                <div>
                  <Label htmlFor="lastName" className="text-amber-200/60">{t('checkout.lastName')}</Label>
                  <Input
                    id="lastName"
                    value={form.lastName}
                    onChange={(e) => updateField('lastName', e.target.value)}
                    className="mt-1 border-amber-900/40 bg-stone-800/50 text-amber-50"
                  />
                  {errors.lastName && <p className="mt-1 text-xs text-red-400">{errors.lastName}</p>}
                </div>
                <div className="sm:col-span-2">
                  <Label htmlFor="address" className="text-amber-200/60">{t('checkout.address')}</Label>
                  <Input
                    id="address"
                    value={form.address}
                    onChange={(e) => updateField('address', e.target.value)}
                    className="mt-1 border-amber-900/40 bg-stone-800/50 text-amber-50"
                  />
                  {errors.address && <p className="mt-1 text-xs text-red-400">{errors.address}</p>}
                </div>
                <div>
                  <Label htmlFor="city" className="text-amber-200/60">{t('checkout.city')}</Label>
                  <Input
                    id="city"
                    value={form.city}
                    onChange={(e) => updateField('city', e.target.value)}
                    className="mt-1 border-amber-900/40 bg-stone-800/50 text-amber-50"
                  />
                  {errors.city && <p className="mt-1 text-xs text-red-400">{errors.city}</p>}
                </div>
                <div>
                  <Label htmlFor="state" className="text-amber-200/60">{t('checkout.state')}</Label>
                  <Input
                    id="state"
                    value={form.state}
                    onChange={(e) => updateField('state', e.target.value)}
                    className="mt-1 border-amber-900/40 bg-stone-800/50 text-amber-50"
                  />
                  {errors.state && <p className="mt-1 text-xs text-red-400">{errors.state}</p>}
                </div>
                <div>
                  <Label htmlFor="zipCode" className="text-amber-200/60">{t('checkout.zipCode')}</Label>
                  <Input
                    id="zipCode"
                    value={form.zipCode}
                    onChange={(e) => updateField('zipCode', e.target.value)}
                    className="mt-1 border-amber-900/40 bg-stone-800/50 text-amber-50"
                  />
                  {errors.zipCode && <p className="mt-1 text-xs text-red-400">{errors.zipCode}</p>}
                </div>
                <div>
                  <Label htmlFor="country" className="text-amber-200/60">{t('checkout.country')}</Label>
                  <Input
                    id="country"
                    value={form.country}
                    onChange={(e) => updateField('country', e.target.value)}
                    className="mt-1 border-amber-900/40 bg-stone-800/50 text-amber-50"
                  />
                </div>
                <div>
                  <Label htmlFor="phone" className="text-amber-200/60">{t('checkout.phone')}</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={form.phone}
                    onChange={(e) => updateField('phone', e.target.value)}
                    className="mt-1 border-amber-900/40 bg-stone-800/50 text-amber-50"
                  />
                </div>
              </div>
            </div>

            {/* Delivery Type */}
            <div className="rounded-lg border border-amber-900/20 bg-stone-900/60 p-6">
              <div className="flex items-center gap-2">
                <Truck className="h-5 w-5 text-amber-400" />
                <h3 className="text-lg font-semibold text-amber-100">{t('checkout.deliveryType')}</h3>
              </div>
              <div className="mt-4 space-y-3">
                {DELIVERY_OPTIONS.map((option) => (
                  <label
                    key={option.id}
                    className={`flex cursor-pointer items-center justify-between rounded-lg border p-4 transition-all ${
                      deliveryType === option.id
                        ? 'border-amber-500/50 bg-amber-900/20'
                        : 'border-amber-900/20 bg-stone-800/30 hover:border-amber-900/40'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <input
                        type="radio"
                        name="deliveryType"
                        value={option.id}
                        checked={deliveryType === option.id}
                        onChange={() => setDeliveryType(option.id)}
                        className="h-4 w-4 accent-amber-600"
                      />
                      <div>
                        <p className="text-sm font-medium text-amber-100">{option.label}</p>
                        <p className="text-xs text-amber-200/40">{option.estimatedDays}</p>
                      </div>
                    </div>
                    <span className={`text-sm font-semibold ${
                      option.id === 'standard' && subtotal > 500
                        ? 'text-emerald-400'
                        : 'text-amber-200/60'
                    }`}>
                      {option.id === 'standard'
                        ? (subtotal > 500 ? t('common.free') : format(50))
                        : format(option.price)
                      }
                    </span>
                  </label>
                ))}
              </div>
            </div>

            {/* Gift Options */}
            <div className="rounded-lg border border-amber-900/20 bg-stone-900/60 p-6">
              <button
                type="button"
                onClick={() => setGiftOptionsOpen(!giftOptionsOpen)}
                className="flex w-full items-center justify-between"
              >
                <div className="flex items-center gap-2">
                  <Gift className="h-5 w-5 text-amber-400" />
                  <h3 className="text-lg font-semibold text-amber-100">{t('checkout.giftOptions')}</h3>
                </div>
                {giftOptionsOpen ? (
                  <ChevronUp className="h-5 w-5 text-amber-200/40" />
                ) : (
                  <ChevronDown className="h-5 w-5 text-amber-200/40" />
                )}
              </button>

              <AnimatePresence>
                {giftOptionsOpen && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="overflow-hidden"
                  >
                    <div className="mt-4 space-y-4">
                      {/* Gift Wrapping Toggle */}
                      <div className="flex items-center gap-3">
                        <Checkbox
                          id="giftWrapping"
                          checked={giftWrapping}
                          onCheckedChange={(checked) => {
                            setGiftWrapping(checked as boolean);
                            if (!checked) setGiftWrapStyle('classic');
                          }}
                          className="border-amber-600 data-[state=checked]:bg-amber-600 data-[state=checked]:border-amber-600"
                        />
                        <Label htmlFor="giftWrapping" className="text-sm text-amber-100">
                          {t('checkout.giftWrapping')}
                        </Label>
                      </div>

                      {/* Gift Wrap Style */}
                      {giftWrapping && (
                        <motion.div
                          initial={{ opacity: 0, y: -8 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="pl-7"
                        >
                          <Label className="text-xs text-amber-200/50">{t('checkout.wrapStyle')}</Label>
                          <Select value={giftWrapStyle} onValueChange={setGiftWrapStyle}>
                            <SelectTrigger className="mt-1 w-full border-amber-900/40 bg-stone-800/50 text-amber-50">
                              <SelectValue placeholder="Select style" />
                            </SelectTrigger>
                            <SelectContent className="border-amber-900/30 bg-stone-900">
                              {GIFT_WRAP_STYLES.map((style) => (
                                <SelectItem key={style.value} value={style.value}>
                                  <div>
                                    <span className="text-amber-100">{style.label}</span>
                                    <span className="ml-2 text-xs text-amber-200/40">— {style.description}</span>
                                  </div>
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </motion.div>
                      )}

                      {/* Greeting Message */}
                      <div className="pl-7">
                        <Label htmlFor="greetingMessage" className="text-xs text-amber-200/50">
                          {t('checkout.greetingMessage')}
                        </Label>
                        <Textarea
                          id="greetingMessage"
                          value={greetingMessage}
                          onChange={(e) => {
                            if (e.target.value.length <= 200) {
                              setGreetingMessage(e.target.value);
                            }
                          }}
                          placeholder={t('checkout.greetingPlaceholder')}
                          rows={3}
                          className="mt-1 border-amber-900/40 bg-stone-800/50 text-amber-50 placeholder:text-amber-200/20 resize-none"
                        />
                        <p className="mt-1 text-xs text-amber-200/30">
                          {t('checkout.charactersCount', { count: String(greetingMessage.length) })}
                        </p>
                      </div>

                      {/* Hide Price Toggle */}
                      <div className="flex items-center gap-3 pl-7">
                        <Checkbox
                          id="hidePrice"
                          checked={hidePrice}
                          onCheckedChange={(checked) => setHidePrice(checked as boolean)}
                          className="border-amber-600 data-[state=checked]:bg-amber-600 data-[state=checked]:border-amber-600"
                        />
                        <Label htmlFor="hidePrice" className="text-sm text-amber-100">
                          {t('checkout.hidePrice')}
                        </Label>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Coupon Code */}
            <div className="rounded-lg border border-amber-900/20 bg-stone-900/60 p-6">
              <div className="flex items-center gap-2">
                <Tag className="h-5 w-5 text-amber-400" />
                <h3 className="text-lg font-semibold text-amber-100">{t('checkout.couponCode')}</h3>
              </div>
              <div className="mt-4">
                {couponResult?.valid ? (
                  <div className="flex items-center justify-between rounded-lg border border-emerald-600/30 bg-emerald-900/20 p-3">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-emerald-400" />
                      <div>
                        <p className="text-sm font-medium text-emerald-300">
                          {couponResult.offer?.title || couponCode}
                        </p>
                        <p className="text-xs text-emerald-400/60">
                          {t('checkout.discountLabel', { amount: format(discount) })}
                        </p>
                      </div>
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={handleRemoveCoupon}
                      className="text-amber-200/40 hover:text-red-400"
                    >
                      <XCircle className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <Input
                      value={couponCode}
                      onChange={(e) => {
                        setCouponCode(e.target.value);
                        if (couponResult && !couponResult.valid) setCouponResult(null);
                      }}
                      placeholder={t('checkout.enterCode')}
                      className="flex-1 border-amber-900/40 bg-stone-800/50 text-amber-50 placeholder:text-amber-200/20"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      onClick={handleApplyCoupon}
                      disabled={couponLoading || !couponCode.trim()}
                      className="border-amber-900/40 text-amber-200/60 hover:bg-amber-900/20 hover:text-amber-400"
                    >
                      {couponLoading ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        t('checkout.apply')
                      )}
                    </Button>
                  </div>
                )}
                {couponResult && !couponResult.valid && (
                  <p className="mt-2 text-xs text-red-400">{couponResult.error}</p>
                )}
              </div>
            </div>

            {/* Note about checkout */}
            <div className="rounded-lg border border-amber-600/20 bg-amber-950/10 p-4">
              <div className="flex items-start gap-3">
                <ShoppingBag className="mt-0.5 h-5 w-5 flex-shrink-0 text-amber-500" />
                <div>
                  <p className="text-sm font-medium text-amber-200">Completing your purchase</p>
                  <p className="mt-1 text-xs text-amber-200/50">
                    When you click &quot;Place Order&quot;, your order will be placed and a confirmation will be sent to your email.
                    Shipping details and delivery preferences will be processed as selected above.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Order Summary Sidebar */}
          <div className="h-fit rounded-lg border border-amber-900/20 bg-stone-900/60 p-6">
            <h3 className="text-lg font-semibold text-amber-100">{t('checkout.orderSummary')}</h3>

            <div className="mt-4 space-y-3 max-h-64 overflow-y-auto">
              {cartItems.map((item) => (
                <div key={item.productId} className="flex justify-between text-sm">
                  <span className="text-amber-200/60 truncate mr-2">
                    {item.name} x{item.quantity}
                  </span>
                  <span className="text-amber-100 flex-shrink-0">
                    {format(item.price * item.quantity)}
                  </span>
                </div>
              ))}
            </div>

            <Separator className="my-4 bg-amber-900/30" />

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-amber-200/50">{t('cart.subtotal')}</span>
                <span className="text-amber-100">{format(subtotal)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-amber-200/50">{t('cart.shipping')} ({selectedDelivery.label})</span>
                <span className="text-amber-100">
                  {shipping === 0 ? (
                    <span className="text-emerald-400">{t('common.free')}</span>
                  ) : (
                    format(shipping)
                  )}
                </span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-sm">
                  <span className="text-amber-200/50">{t('cart.discount')}</span>
                  <span className="text-emerald-400">-{format(discount)}</span>
                </div>
              )}
              <div className="flex justify-between text-sm">
                <span className="text-amber-200/50">{t('cart.tax')}</span>
                <span className="text-amber-100">{format(tax)}</span>
              </div>
              {giftWrapping && (
                <div className="flex justify-between text-sm">
                  <span className="text-amber-200/50">{t('checkout.giftWrappingLabel', { style: giftWrapStyle })}</span>
                  <span className="text-amber-400 text-xs">{t('checkout.included')}</span>
                </div>
              )}
              <Separator className="bg-amber-900/30" />
              <div className="flex justify-between">
                <span className="font-semibold text-amber-100">{t('cart.total')}</span>
                <span className="text-lg font-bold text-amber-400">
                  {format(total)}
                </span>
              </div>
            </div>

            {/* Place Order button */}
            <Button
              type="submit"
              disabled={checkoutLoading}
              className="mt-6 w-full bg-amber-600 text-stone-950 hover:bg-amber-500 hover:shadow-lg hover:shadow-amber-600/25 font-semibold"
              size="lg"
            >
              {checkoutLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Placing your order...
                </>
              ) : (
                <>
                  <Lock className="mr-2 h-4 w-4" />
                  {`${t('checkout.placeOrder')} - ${format(total)}`}
                </>
              )}
            </Button>

            {/* Secure Checkout Badge */}
            <div className="mt-4 flex items-center justify-center gap-1.5 text-amber-200/30">
              <Lock className="h-3 w-3" />
              <span className="text-xs">Secure Checkout</span>
            </div>

            {checkoutError && (
              <div className="mt-3 rounded-lg border border-red-900/30 bg-red-950/20 p-3">
                <p className="text-center text-sm text-red-400">
                  {checkoutError}
                </p>
              </div>
            )}
          </div>
        </div>
      </form>
    </motion.div>
  );
}